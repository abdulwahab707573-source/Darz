# Wahab Store — Daraz Linked Website

1. Open `index.html`.
2. Each product has a `Buy on Daraz` button.
3. Replace `https://www.daraz.pk/` with the real Daraz product URL.
4. Upload `index.html` to a GitHub repository.
5. GitHub → Settings → Pages → Deploy from branch → main → root → Save.
6. Your website will become live on GitHub Pages.

This is an external-link storefront. It does not process Daraz orders or payments itself.
